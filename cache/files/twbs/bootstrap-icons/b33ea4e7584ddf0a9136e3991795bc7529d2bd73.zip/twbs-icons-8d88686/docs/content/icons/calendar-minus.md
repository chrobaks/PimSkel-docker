---
title: Calendar minus
categories:
  - Date and time
tags:
  - date
  - time
  - month
---
