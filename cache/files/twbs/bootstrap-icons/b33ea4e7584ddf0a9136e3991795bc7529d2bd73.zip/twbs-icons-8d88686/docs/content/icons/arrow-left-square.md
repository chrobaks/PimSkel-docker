---
title: Arrow left square
categories:
  - Shape Arrows
tags:
  - arrow
  - square
---
