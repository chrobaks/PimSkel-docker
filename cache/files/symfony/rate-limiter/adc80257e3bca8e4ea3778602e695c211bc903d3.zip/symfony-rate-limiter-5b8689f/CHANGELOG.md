CHANGELOG
=========

6.4
---

 * Add `SlidingWindowLimiter::reserve()`

6.2
---

 * Move `symfony/lock` to dev dependency in `composer.json`

5.4
---

 * The component is not experimental anymore
 * Add support for long intervals (months and years)

5.2.0
-----

 * added the component
