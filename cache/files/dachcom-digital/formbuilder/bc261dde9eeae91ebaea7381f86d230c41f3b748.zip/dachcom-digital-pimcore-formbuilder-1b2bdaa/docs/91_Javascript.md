# Javascript Plugins
We're providing some helpful Javascript Plugins to simplify your daily work with FormBuilder.

***

## VanillaJs
All Extensions are available on npmjs.com via [js-pimcore-formbuilder](https://www.npmjs.com/package/js-pimcore-formbuilder). 

### Installation
```bash
npm i js-pimcore-formbuilder
```

Read more about installation and usage on [github](https://github.com/dachcom-digital/js-pimcore-formbuilder).

***

## jQuery
All jQuery Extensions are available on npmjs.com via [jquery-pimcore-formbuilder](https://www.npmjs.com/package/jquery-pimcore-formbuilder). 

### Installation
```bash
npm i jquery-pimcore-formbuilder
```

Read more about installation and usage on [github](https://github.com/dachcom-digital/jquery-pimcore-formbuilder).

***

## Alpine.js
TBD
