# Ajax Forms

### Activation
First, check 'Ajax Submission' in your form configuration.

### Javascript Plugins
If you want to use ajax driven forms you need to load the FormBuilder Js-Library. 
To enable this feature you need the FormBuilder core extension. Please read [this documentation](91_Javascript.md) to learn how to **enable the required plugins**.
