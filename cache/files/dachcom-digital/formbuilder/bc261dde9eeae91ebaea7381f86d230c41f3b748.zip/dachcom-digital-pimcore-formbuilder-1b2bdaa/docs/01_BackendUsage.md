# Backend Administration of Forms

## Form Grouping
![](http://g.recordit.co/AOOhEiGeKp.gif)
It's possible to group your forms in order keep your form organized.
Just define a group name per form and you'll get a folder-organized tree view.

## Meta Information
<img src="https://user-images.githubusercontent.com/700119/48311937-8ba5d400-e5a7-11e8-9e55-a7807aecd730.png">
There are some meta information about each form you've created. Just click the blue "Info"-Button in the `Base` Section.

| Name | Description |
|------|-------------|
| Creation Date | -- |
| Modification Date | -- |
| User Owner| -- |
| User Modification | -- |
| Required By | List all Documents which are using the current form |
