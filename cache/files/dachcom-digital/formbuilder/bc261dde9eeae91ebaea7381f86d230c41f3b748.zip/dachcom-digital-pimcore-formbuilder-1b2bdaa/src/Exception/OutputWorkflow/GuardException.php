<?php

namespace FormBuilderBundle\Exception\OutputWorkflow;

class GuardException extends \Exception
{
}
