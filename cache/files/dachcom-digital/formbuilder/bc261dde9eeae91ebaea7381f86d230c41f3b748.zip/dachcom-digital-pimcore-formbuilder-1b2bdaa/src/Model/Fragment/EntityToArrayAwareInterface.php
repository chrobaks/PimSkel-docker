<?php

namespace FormBuilderBundle\Model\Fragment;

interface EntityToArrayAwareInterface
{
    public function toArray(): array;
}
